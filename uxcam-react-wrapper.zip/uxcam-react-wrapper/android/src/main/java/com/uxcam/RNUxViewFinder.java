package com.uxcam;

import android.view.View;

interface RNUxViewFinder {
    public void obtainView(View view);
}